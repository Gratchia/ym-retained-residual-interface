# A Bianchi-Compatible Retained/Residual Interface for Finite Lattice Yang--Mills Theory

**SciPost Physics Core preparation draft v1.3**  
**Status:** SR4Q-adopted qualified internal review draft after full-text Batrouni/BVF audit  
**Author:** Gratchia Mkrttchian  
**Affiliation:** Higher Colleges of Technology - CERT; The Centre of Excellence for Applied Research & Training; Al Ain, Emirate of Abu Dhabi, United Arab Emirates  
**Email:** gratchiamkrttchian@gmail.com  
**ORCID:** 0000-0003-4444-6138  
**Scope:** finite-regulator structural interface only; certified cuboidal templates and conditional reflection-admissible stems  
**No claim:** continuum construction, OS reconstruction, transfer decay, confinement, or mass gap

---

## Abstract

We introduce a finite-regulator retained/residual coordinate interface for lattice Yang--Mills theory. The construction separates covariant connector and Bianchi bookkeeping data from gauge-invariant quotient observables and measures. For certified cuboidal templates, the interface satisfies an exact-image Bianchi compatibility statement verified by finite edge-word reductions. Under a reflection-admissible retained stem/template condition, positive-support quotient coordinate observables pull back to positive-time gauge-invariant lattice observables. The accompanying diagnostic ledger separates exact structural conditions from exposed chart/frame/stratum records and future analytic templates. The results are finite-regulator structural statements only. No continuum limit, Osterwalder--Schrader reconstruction, transfer decay, confinement theorem, or spectral mass-gap theorem is claimed.

---

## 1. Introduction

The Yang--Mills existence and mass-gap problem asks for a mathematically well-defined four-dimensional quantum Yang--Mills theory with a positive spectral gap. A possible Euclidean route begins from finite lattice gauge theory, seeks continuum Euclidean Schwinger functions satisfying appropriate axioms, reconstructs a Hilbert space and Hamiltonian, and then proves a spectral gap above the vacuum.

This paper addresses only a finite-regulator structural component of that broader program. We work at a fixed finite Wilson lattice regulator and study a retained/residual coordinate interface designed to keep track of three structural issues:

1. nonabelian Bianchi compatibility;
2. positive-time support compatibility;
3. gauge/orbit quotient compatibility.

The paper does not construct the continuum theory and does not prove a mass gap.

### 1.1 Relation to prior work and scope of contribution

The construction in this paper is finite-regulator and structural. It builds on the standard Wilson lattice formulation of gauge theory and on the Euclidean constructive/axiomatic perspective associated with reflection positivity and Osterwalder--Schrader reconstruction. It does not construct the continuum Yang--Mills theory and does not prove a mass gap.

The Bianchi and plaquette aspects of the present paper sit in a well-established line of prior work. Batrouni's plaquette formulation already places lattice Bianchi identities at the center of a plaquette-variable description of Abelian and nonabelian lattice gauge theory, including gauge-invariant plaquettes and abelianization questions. Borisenko--Voloshin--Faber further refine this direction by modifying Batrouni's nonabelian Bianchi constraints so that each identity contains two connectors instead of four.

Accordingly, the present paper does not claim novelty for plaquette variables, lattice Bianchi identities, gauge-invariant plaquettes, connector structures, or nonabelian Bianchi simplification. Its contribution is instead the proposed retained/residual interface and its claim-control discipline: covariant connector/Bianchi bookkeeping is kept separate from gauge-invariant quotient observables and measures; exact-image Bianchi compatibility is restricted to certified cuboidal templates; reflection-support statements are made conditional on a common-conjugation stem admissibility condition; and the diagnostic ledger separates exact structural conditions from exposed chart/frame/stratum records and from future analytic templates.

All main results in this paper are finite-regulator structural statements. No continuum limit, OS reconstruction, transfer decay, confinement statement, or spectral mass-gap theorem is claimed.


---

## 2. Finite Wilson lattice setup

Let \(G\) be a compact Lie group. For the intended Yang--Mills application one may keep \(G=SU(2)\), although most finite-regulator definitions below apply to compact gauge groups.

Let \(\Lambda\) be a finite hypercubic lattice with finite oriented edge set \(E\) and vertex set \(V\). The finite configuration space is

\[
\mathcal U_{\Lambda,a}=G^E,
\]

equipped with the product Borel sigma-algebra. Since \(G\) is compact metrizable and \(E\) is finite, \(\mathcal U_{\Lambda,a}\) is compact metrizable and standard Borel.

The finite gauge group is

\[
\mathcal G_{\Lambda,a}=G^V.
\]

It acts on a link configuration \(U\in G^E\) by the endpoint action

\[
(g\cdot U)_e
=
g_{s(e)}U_e g_{t(e)}^{-1},
\]

with the usual orientation convention.

The Wilson measure at finite regulator is denoted

\[
\mu_{\Lambda,a}.
\]

This paper uses only finite-regulator pushforwards and disintegrations of this finite measure.

---

## 3. Retained stemmed-loop variables

For a scale \(k\), choose a finite retained template catalogue. A retained generator is a stemmed loop word

\[
W_i=S_i\gamma_iS_i^{-1},
\qquad i=1,\dots,n_k,
\]

where \(S_i\) is a stem from a common block anchor to the loop basepoint, and \(\gamma_i\) is a loop word.

Define the raw retained map

\[
R_k:\mathcal U_{\Lambda,a}\to G^{n_k},
\]

\[
R_k(U)=
\bigl(
U(W_1),\dots,U(W_{n_k})
\bigr).
\]

The map \(R_k\) is Borel measurable because it is built from finitely many coordinate projections, multiplication, and inversion in \(G\).

The raw retained tuple transforms covariantly under the gauge transformation at the common anchor. Therefore the gauge-invariant retained coordinate is the simultaneous-conjugacy quotient

\[
X_k=q_k^{\rm ret}\circ R_k,
\]

where

\[
q_k^{\rm ret}:G^{n_k}\to\mathcal X_k
\]

is the retained quotient map, with orbit-type or stabilizer-stratum labels included when needed. The quotient codomain \(\mathcal X_k\) is treated as a standard-Borel space.

---

## 4. Residual coordinates, quotient interface, and disintegration

The residual layer is an actual measurable coordinate map

\[
Y_k^{\rm res,loc}:\mathcal U_{\Lambda,a}\to\mathcal Y_k,
\]

where \(\mathcal Y_k\) is a declared standard-Borel product space containing the group-valued residual variables, labels, support records, connector records, and failure records required by the interface. A model form is

\[
\mathcal Y_k
=
G^{m_k}
\times
\mathcal L_k
\times
\mathcal S_k
\times
\mathcal C_k
\times
\mathcal E_k,
\]

where the non-group factors are finite or standard-Borel record spaces.

The associated residual sigma-algebra is

\[
\mathscr Y_k^{\rm res,loc}
=
\sigma(Y_k^{\rm res,loc}).
\]

The map and its generated sigma-algebra must not be confused.

The residual map may be gauge-covariant rather than gauge-invariant. Therefore we distinguish the covariant bookkeeping interface from the quotient interface.

The covariant interface is used for connector and Bianchi bookkeeping:

\[
\Phi_k^{\rm cov}=(R_k,Y_k^{\rm res,loc}).
\]

For gauge-invariant observables and measures, use the quotient interface

\[
\Phi_k^{\rm quot}=(X_k,[Y_k]),
\]

where \([Y_k]\) is the quotient residual class under the induced residual gauge action.

Define

\[
\mu_k^{XY}=(\Phi_k^{\rm quot})_*\mu_{\Lambda,a},
\qquad
\mu_k^X=(X_k)_*\mu_{\Lambda,a}.
\]

Since the coordinate spaces are standard Borel, there exists a regular conditional probability kernel

\[
K_k(dy\mid x)
\]

such that

\[
\mu_k^{XY}(dx,dy)
=
\mu_k^X(dx)K_k(dy\mid x).
\]

This disintegration is purely measure-theoretic. No locality, smoothness, mixing, or decay property of \(K_k\) is assumed.

For Bianchi bookkeeping, let

\[
\pi_B:\mathcal Y_k\to\mathcal Y_k^B
\]

be the measurable projection onto the Bianchi-relevant residual records. Define

\[
Y_k^B=\pi_B\circ Y_k^{\rm res,loc}
\]

and

\[
\mu_k^{X,B}=(X_k,Y_k^B)_*\mu_{\Lambda,a}.
\]

The typed Bianchi support statement is

\[
\mu_k^{X,B}
\left(
\mathcal Z_k^{\rm Bianchi,XY}
\right)
=
1,
\]

or equivalently,

\[
\mu_k^{XY}
\left(
(\operatorname{id}\times\pi_B)^{-1}
\mathcal Z_k^{\rm Bianchi,XY}
\right)
=
1.
\]

A local residual component \(Y_{k,B}^{\rm res,loc}\) is said to have collar locality \(r\) if it is measurable with respect to

\[
\sigma(U_e:e\subset B^{+r}).
\]

This is a measurable-map statement, not a set-inclusion statement for coordinate values.

---

## 5. Reflection notation and reflection-admissible stems

Let

\[
\Theta:\mathcal U_{\Lambda,a}\to\mathcal U_{\Lambda,a}
\]

be the finite-lattice time reflection. The edge-reflection and orientation conventions are fixed once and for all.

When the retained stem/template system is reflection-admissible, reflection induces a retained quotient map

\[
\Theta_k^X:\mathcal X_k\to\mathcal X_k
\]

satisfying

\[
X_k(\Theta U)=\Theta_k^X X_k(U).
\]

The reflection-admissibility condition is a common-conjugation condition on retained stemmed loop words. Suppose the retained words in a block are

\[
W_i=S_i\gamma_iS_i^{-1},
\qquad i=1,\dots,n_B.
\]

The retained stem/template system is reflection-admissible if there exist a permutation \(\pi_B\), signs \(\epsilon_i\in\{\pm1\}\), and one common conjugating word \(C_B\), independent of \(i\), such that

\[
\operatorname{red}(\Theta W_i)
=
\operatorname{red}
\left(
C_BW_{\pi_B(i)}^{\epsilon_i}C_B^{-1}
\right)
\]

for every retained generator \(i\).

Loop-dependent conjugations are not absorbed by simultaneous conjugacy of the retained tuple. Thus the same word \(C_B\) must work for the whole tuple.

Failure of this condition is recorded by

\[
N_k^{\rm stem/RP}.
\]

For residual coordinates, assume a measurable map

\[
\Theta_k^Y:\mathcal Y_k\to\mathcal Y_k
\]

such that

\[
Y_k^{\rm res,loc}(\Theta U)=\Theta_k^Y Y_k^{\rm res,loc}(U)
\]

for the declared finite template class. The joint coordinate reflection is

\[
\Theta_k^{X,Y}(x,y)
=
(\Theta_k^Xx,\Theta_k^Yy).
\]

For Bianchi-relevant residual data, let

\[
Y_k^B=\pi_B\circ Y_k^{\rm res,loc}.
\]

The projected reflection map is

\[
\Theta_k^B:\mathcal Y_k^B\to\mathcal Y_k^B
\]

and must satisfy

\[
\pi_B\Theta_k^Y=\Theta_k^B\pi_B.
\]

Thus the projected joint reflection is

\[
\Theta_k^{X,B}(x,y^B)
=
(\Theta_k^Xx,\Theta_k^B y^B).
\]

The reflection of a Bianchi boundary product is defined by

\[
(\Theta\mathcal B)_c(U)
=
\mathcal B_{\Theta c}(\Theta U),
\]

with the declared orientation, basepoint, and connector conventions.

All reflection-support statements in the paper are conditional on the relevant reflection-admissibility and projection-commutation assumptions.

---

## 6. Bianchi spaces and certified cuboidal templates

The exact-image Bianchi theorem in this paper is restricted to certified admissible cuboidal templates.

For a finite oriented cubical cell \(c\), choose:

1. a cell basepoint \(b_c\);
2. a face basepoint \(b_f\) for every oriented face \(f\subset\partial c\);
3. connector words \(T_{c,f}\) from \(b_c\) to \(b_f\);
4. oriented face-boundary words \(P_f\);
5. a declared boundary multiplication order.

Define the transported face word

\[
\widetilde P_{c,f}
=
T_{c,f}P_f^{\epsilon(f,c)}T_{c,f}^{-1},
\]

where \(\epsilon(f,c)\in\{\pm1\}\) is the incidence sign.

The Bianchi boundary word is

\[
\mathcal B_c
=
\prod_{f\subset\partial c}^{\rm declared}
\widetilde P_{c,f}.
\]

For certified cuboidal templates, finite edge-word reduction gives

\[
\operatorname{red}(\mathcal B_c)=\varnothing,
\]

hence for every finite configuration \(U\),

\[
\mathcal B_c(U)=e_G.
\]

The current certificate catalogue covers canonical axis-aligned cuboidal templates

\[
1\times1\times1,
\quad
2\times1\times1,
\quad
2\times2\times1,
\quad
2\times2\times2,
\quad
3\times3\times3,
\]

up to coordinate relabelling and orientation reversal. If the manuscript later uses other cell topologies or connector catalogues, new certificates must be supplied.

Let

\[
\mathcal Z_k^{\rm Bianchi,XY}
\]

denote the typed exact-image Bianchi support set in \((x,y^B)\)-space.

---

## 7. Diagnostic ledger

The diagnostic ledger is not an analytic estimate. It is a finite-regulator bookkeeping device separating exact structural conditions from exposed singularities and future analytic templates.

We split

\[
\mathfrak N_k
=
\mathfrak N_k^{\rm exact}
\oplus
\mathfrak N_k^{\rm exposed}
\oplus
\mathfrak N_k^{\rm future}.
\]

The exact structural part is

\[
\mathfrak N_k^{\rm exact}
=
\left(
N_k^{\rm Bianchi},
N_{k,+}^{\rm RP/OS},
N_k^{\rm stem/RP},
N_k^{\rm cov},
N_k^{\rm quot},
N_k^{\rm conn/quot}
\right).
\]

The Bianchi diagnostic is

\[
N_k^{\rm Bianchi}
=
\mathbf 1
\left[
\mu_k^{X,B}
(
\mathcal Z_k^{\rm Bianchi,XY}
)
\ne 1
\right].
\]

The positive-support diagnostic is

\[
N_{k,+}^{\rm RP/OS}
=
\mathbf 1
\left[
\exists f\in\mathcal A_{+,k}^{X,Y}
:
f\circ\Phi_k^{\rm quot}
\notin
\mathcal A_{+,{\rm inv}}^{\rm lat}
\right].
\]

The reflection-stem diagnostic is

\[
N_k^{\rm stem/RP}
=
\mathbf 1
\left[
\exists T\in\mathcal T_k
\text{ without a common-conjugation reflection certificate}
\right].
\]

The diagnostics \(N_k^{\rm cov}\), \(N_k^{\rm quot}\), and \(N_k^{\rm conn/quot}\) record failure of residual gauge covariance, quotient well-definedness, and connector/quotient compatibility.

The exposed structural part is

\[
\mathfrak N_k^{\rm exposed}
=
\left(
N_k^{\rm chart/LF},
N_k^{\rm frame},
N_k^{\rm stratum}
\right).
\]

These record chart/logarithm/half-density failures, gauge-frame failures, and orbit-stratum transitions. They are not claimed to be small.

The future analytic template part includes

\[
N_k^{\rm locality},
\quad
N_k^J,
\quad
N_k^{\rm Cartan},
\quad
N_k^{\rm hi},
\quad
N_k^{\rm obs},
\quad
N_k^{\rm kernel},
\quad
N_k^{\rm BCH},
\quad
N_k^{\rm transfer}.
\]

These are proposed future diagnostics only. Paper 1 does not prove locality estimates, Jacobian bounds, Cartan suppression, high Peter--Weyl tail suppression, kernel locality, BCH control, transfer decay, continuum reconstruction, or mass gap.

### Proposition 7.1 — Ledger scope

Under the certified-template and admissibility assumptions of this paper, the exact structural diagnostics vanish:

\[
N_k^{\rm Bianchi}=0,
\quad
N_{k,+}^{\rm RP/OS}=0,
\quad
N_k^{\rm stem/RP}=0,
\quad
N_k^{\rm cov}=0,
\quad
N_k^{\rm quot}=0,
\quad
N_k^{\rm conn/quot}=0.
\]

The exposed diagnostics are recorded but not estimated, and the future analytic diagnostics are not used as hypotheses in the structural theorems.

#### Proof

Each exact diagnostic is an indicator of failure of a finite structural condition: certified Bianchi support, positive-support pullback, reflection-admissible stems, gauge covariance, quotient well-definedness, or connector/quotient compatibility. Under the corresponding assumptions, the failure indicator is zero. The exposed diagnostics only record where local charts, frames, or strata must be tracked. The future analytic diagnostics require estimates not proved in this paper and therefore play no role in the finite structural theorems. \(\square\)

---

## 8. Exact-image Bianchi compatibility

The theorem below is an exact-image theorem. It is not a representative-independent coordinate blocking theorem.

### Theorem 8.1 — Exact-image Bianchi compatibility for certified cuboidal templates

Assume:

1. the scale-\(k\) and scale-\(k+1\) Bianchi-relevant coordinate data are evaluated from exact finite-lattice holonomy words;
2. every coarse cell belongs to the certified cuboidal template class;
3. the declared connector and boundary-ordering conventions are those used by the certificate;
4. all Bianchi-relevant connector, boundary, and support records are included in \(Y_k^B\).

Then for every finite lattice configuration \(U\),

\[
(X_{k+1}(U),Y_{k+1}^{B}(U))
\in
\mathcal Z_{k+1}^{\rm Bianchi,XY}.
\]

Equivalently,

\[
\mu_{k+1}^{X,B}
\left(
\mathcal Z_{k+1}^{\rm Bianchi,XY}
\right)
=
1.
\]

Thus

\[
N_{k+1}^{\rm Bianchi}=0
\]

for certified cuboidal exact-image templates.

#### Proof

For every certified cuboidal cell \(c\), the finite edge-word certificate gives

\[
\operatorname{red}(\mathcal B_c)=\varnothing.
\]

Therefore for every configuration \(U\),

\[
\mathcal B_c(U)=e_G.
\]

Since \(Y_{k+1}^B\) contains the connector, boundary, and support records required to evaluate the transported Bianchi boundary products, the pair

\[
(X_{k+1}(U),Y_{k+1}^{B}(U))
\]

lies in the exact-image Bianchi support set. Pushing forward the finite Wilson measure gives the measure statement. \(\square\)

### Remark 8.2 — No coordinate blocking theorem

Theorem 8.1 does not construct a representative-independent map

\[
\mathsf B_k:(x_k,y_k)\mapsto(x_{k+1},y_{k+1})
\]

and does not prove

\[
\Phi_{k+1}=\mathsf B_k\circ\Phi_k.
\]

Those are stronger claims and are not part of this paper.

---

## 9. Positive-time support and observable pullback

Let

\[
\mathcal U_{\Lambda,a}=G^E
\]

be the finite lattice configuration space. Fix a time-reflection involution \(\Theta\). Decompose the oriented edge set into

\[
E=E_+\cup E_0\cup E_-,
\]

where \(E_+\) lies strictly in positive time, \(E_0\) lies on the reflection hyperplane, and \(E_-\) lies strictly in negative time.

Define the positive-time sigma-algebra

\[
\mathscr F_+
=
\sigma(U_e:e\in E_+\cup E_0).
\]

The corresponding bounded positive-time observable algebra is

\[
\mathcal A_+^{\rm lat}
=
L^\infty(\mathcal U_{\Lambda,a},\mathscr F_+,\mu_{\Lambda,a}).
\]

The gauge-invariant positive-time observable algebra is

\[
\mathcal A_{+,{\rm inv}}^{\rm lat}
=
\{F\in\mathcal A_+^{\rm lat}:F(g\cdot U)=F(U)
\text{ for all lattice gauge transformations }g\}.
\]

For each retained or residual coordinate generator \(Z_\alpha\), let

\[
{\rm supp}_{\rm full}(Z_\alpha)\subset E
\]

denote the full set of edges used by the generator, including loop words, stems, connector paths, boundary paths, and reflection-support bookkeeping paths. A generator is positive-supported if

\[
{\rm supp}_{\rm full}(Z_\alpha)\subset E_+\cup E_0.
\]

A generator is crossing if its full support intersects both \(E_+\) and \(E_-\). Crossing generators are not allowed in the positive coordinate algebra.

Let

\[
\Phi_k^{\rm quot}=(X_k,[Y_k])
\]

be the quotient retained/residual coordinate interface. Define \(\mathcal A_{+,k}^{X,Y}\) to be the bounded measurable functions of finitely many quotient coordinate generators of \(\Phi_k^{\rm quot}\) such that every generator used is positive-supported and no crossing generator is used.

### Theorem 9.1 — Positive-support pullback

Assume that all coordinate generators have declared full supports and that \(f\in\mathcal A_{+,k}^{X,Y}\). Then

\[
f\circ\Phi_k^{\rm quot}
\in
\mathcal A_{+,{\rm inv}}^{\rm lat}.
\]

#### Proof

The function \(f\) depends only on quotient coordinate generators whose full supports lie in \(E_+\cup E_0\). Therefore its pullback depends only on link variables \(U_e\) with \(e\in E_+\cup E_0\). Hence \(f\circ\Phi_k^{\rm quot}\) is \(\mathscr F_+\)-measurable. It is bounded because \(f\) is bounded. It is gauge-invariant because \(f\) is a function of the quotient coordinates \((X_k,[Y_k])\). Thus

\[
f\circ\Phi_k^{\rm quot}\in \mathcal A_{+,{\rm inv}}^{\rm lat}.
\]

\(\square\)

### Remark 9.2 — Scope

Theorem 9.1 is a support-placement theorem. It does not prove reflection positivity of a pushed-forward measure, OS reconstruction, transfer decay, clustering, continuum existence, or a mass gap.

---

## 10. Limitations and future analytic work

The results above are finite-regulator structural statements. They do not prove:

\[
\text{continuum existence},
\quad
\text{infinite-volume existence},
\quad
\text{OS reconstruction},
\quad
\text{Hamiltonian construction},
\quad
\text{spectral mass gap},
\]

\[
\text{confinement},
\quad
\text{area law},
\quad
\text{clustering},
\quad
\text{transfer decay},
\quad
\text{kernel locality}.
\]

The next analytic stage would require genuine estimates for locality, Jacobians, near-Cartan sectors, high representation tails, kernels, and transfer operators. These are not part of Paper 1.

---

## Declarations

**Funding.** No external funding is declared.

**Competing interests.** The author declares no competing interests.

**AI-use disclosure.** AI assistance was used for manuscript organization, language editing, literature-search support, citation and bibliography organization, formatting, LaTeX/PDF preparation, consistency checks, and internal publication-readiness auditing.

**Code and supplementary material.** The reproducibility package consists of finite word-checking scripts and certificates for the certified cuboidal Bianchi-template statements. A public repository link or archival DOI should be inserted here before journal submission. The reflection-stem certificate is illustrative unless project-specific retained-template certificates are supplied.

## References

The bibliography entries below use verified metadata where available; any subscription-gated source should still be checked against the final publisher record before journal submission.
