#!/usr/bin/env python3
"""
ym_bianchi_cuboid_template_checker_v0_3.py

Template catalogue checker for nonabelian Bianchi word identities on
axis-aligned cuboidal boundary surfaces.

Scope:
- Certifies boundary-shelling word reduction for cuboids (nx,ny,nz).
- Verifies internal face opposite-orientation pairing for cuboids tiled by
  unit cubes.
- Intended for 3D cubical cells embedded in a 4D hypercubic lattice by
  relabelling coordinate directions.

It does not certify arbitrary non-cuboidal topologies or arbitrary connector
trees. Those require separate template certificates.
"""

from __future__ import annotations
from pathlib import Path
from typing import List, Tuple, Dict, Any, Optional
from collections import Counter, defaultdict
import json

Vertex = str
Edge = Tuple[Vertex, Vertex]
Word = List[Edge]


def v(x: int, y: int, z: int) -> Vertex:
    return f"{x},{y},{z}"


def inv_edge(e: Edge) -> Edge:
    return (e[1], e[0])


def inv_word(w: Word) -> Word:
    return [inv_edge(e) for e in reversed(w)]


def reduce_word(word: Word) -> Word:
    out: Word = []
    for e in word:
        if out and out[-1] == inv_edge(e):
            out.pop()
        else:
            out.append(e)
    return out


def vertices_to_edges(vs: List[Vertex]) -> Word:
    return [(vs[i], vs[(i + 1) % len(vs)]) for i in range(len(vs))]


def is_closed_continuous(word: Word) -> bool:
    if not word:
        return True
    cur = word[0][0]
    for e in word:
        if e[0] != cur:
            return False
        cur = e[1]
    return cur == word[0][0]


def boundary_vertices(boundary: Word) -> List[Vertex]:
    if not boundary:
        return []
    verts = [boundary[0][0]]
    cur = boundary[0][0]
    for e in boundary:
        if e[0] != cur:
            raise ValueError(f"Boundary not continuous at edge {e}; expected source {cur}")
        cur = e[1]
        verts.append(cur)
    if verts[-1] != verts[0]:
        raise ValueError("Boundary is not closed")
    return verts[:-1]


def prefix_path_to_vertex(boundary: Word, vertex: Vertex) -> Optional[Word]:
    if not boundary:
        return []
    cur = boundary[0][0]
    if cur == vertex:
        return []
    path: Word = []
    for e in boundary:
        path.append(e)
        cur = e[1]
        if cur == vertex:
            return path
    return None


def rotate_cycle_to_vertex(edges: Word, start: Vertex) -> Optional[Word]:
    for i, e in enumerate(edges):
        if e[0] == start:
            return edges[i:] + edges[:i]
    return None


def cyclic_equal(a: Word, b: Word) -> bool:
    if len(a) != len(b):
        return False
    if not a and not b:
        return True
    doubled = b + b
    for i in range(len(b)):
        if doubled[i:i+len(a)] == a:
            return True
    return False


def cyclic_inverse_equal(a: Word, b: Word) -> bool:
    return cyclic_equal(a, inv_word(b))


def cuboid_boundary_faces(nx: int, ny: int, nz: int) -> Dict[str, Word]:
    """Outward-oriented unit square faces of the cuboid [0,nx]x[0,ny]x[0,nz]."""
    faces: Dict[str, Word] = {}

    # +x and -x
    for y in range(ny):
        for z in range(nz):
            faces[f"x+:{y},{z}"] = vertices_to_edges([
                v(nx, y, z), v(nx, y + 1, z), v(nx, y + 1, z + 1), v(nx, y, z + 1)
            ])
            faces[f"x-:{y},{z}"] = vertices_to_edges([
                v(0, y, z), v(0, y, z + 1), v(0, y + 1, z + 1), v(0, y + 1, z)
            ])

    # +y and -y
    for x in range(nx):
        for z in range(nz):
            faces[f"y+:{x},{z}"] = vertices_to_edges([
                v(x, ny, z), v(x, ny, z + 1), v(x + 1, ny, z + 1), v(x + 1, ny, z)
            ])
            faces[f"y-:{x},{z}"] = vertices_to_edges([
                v(x, 0, z), v(x + 1, 0, z), v(x + 1, 0, z + 1), v(x, 0, z + 1)
            ])

    # +z and -z
    for x in range(nx):
        for y in range(ny):
            faces[f"z+:{x},{y}"] = vertices_to_edges([
                v(x, y, nz), v(x + 1, y, nz), v(x + 1, y + 1, nz), v(x, y + 1, nz)
            ])
            faces[f"z-:{x},{y}"] = vertices_to_edges([
                v(x, y, 0), v(x, y + 1, 0), v(x + 1, y + 1, 0), v(x + 1, y, 0)
            ])

    return faces


def unit_cube_faces_at(i: int, j: int, k: int) -> Dict[str, Word]:
    """Oriented boundary faces of the unit cube [i,i+1]x[j,j+1]x[k,k+1]."""
    return {
        f"x+:{i+1}:{j},{k}": vertices_to_edges([
            v(i+1, j, k), v(i+1, j+1, k), v(i+1, j+1, k+1), v(i+1, j, k+1)
        ]),
        f"x-:{i}:{j},{k}": vertices_to_edges([
            v(i, j, k), v(i, j, k+1), v(i, j+1, k+1), v(i, j+1, k)
        ]),
        f"y+:{j+1}:{i},{k}": vertices_to_edges([
            v(i, j+1, k), v(i, j+1, k+1), v(i+1, j+1, k+1), v(i+1, j+1, k)
        ]),
        f"y-:{j}:{i},{k}": vertices_to_edges([
            v(i, j, k), v(i+1, j, k), v(i+1, j, k+1), v(i, j, k+1)
        ]),
        f"z+:{k+1}:{i},{j}": vertices_to_edges([
            v(i, j, k+1), v(i+1, j, k+1), v(i+1, j+1, k+1), v(i, j+1, k+1)
        ]),
        f"z-:{k}:{i},{j}": vertices_to_edges([
            v(i, j, k), v(i, j+1, k), v(i+1, j+1, k), v(i+1, j, k)
        ]),
    }


def face_geom_key(word: Word) -> Tuple[Tuple[Vertex, ...]]:
    # Orientation-free key: sorted vertices of the square.
    verts = sorted({p for e in word for p in e})
    return (tuple(verts),)


def edge_balance_certificate(faces: Dict[str, Word]) -> Dict[str, Any]:
    counts: Counter[Edge] = Counter()
    for word in faces.values():
        for e in word:
            counts[e] += 1

    failures = []
    for e in sorted(counts):
        inv = inv_edge(e)
        if counts[e] != counts[inv]:
            failures.append({
                "edge": list(e),
                "count_edge": counts[e],
                "inverse": list(inv),
                "count_inverse": counts[inv],
            })

    return {
        "edge_balance_ok": not failures,
        "failures": failures,
        "number_oriented_edges": len(counts),
    }


def attachment_candidates(boundary: Word, face: Word):
    out = []
    for vert in set(boundary_vertices(boundary)):
        T = prefix_path_to_vertex(boundary, vert)
        rotated = rotate_cycle_to_vertex(face, vert)
        if T is None or rotated is None:
            continue
        trial = boundary + T + rotated + inv_word(T)
        reduced = reduce_word(trial)
        if is_closed_continuous(reduced) and len(reduced) < len(boundary) + len(rotated) + 2 * len(T):
            reduction = len(boundary) + len(rotated) + 2 * len(T) - len(reduced)
            out.append((reduction, vert, T, rotated, reduced))
    out.sort(reverse=True, key=lambda x: (x[0], -len(x[4])))
    return out


def greedy_boundary_shelling(faces: Dict[str, Word]) -> Dict[str, Any]:
    for start in sorted(faces):
        boundary = faces[start]
        remaining = set(faces) - {start}
        order = [start]
        steps = [{
            "start_face": start,
            "boundary_after_reduction_length": len(boundary),
        }]

        while remaining:
            best = None
            for name in sorted(remaining):
                candidates = attachment_candidates(boundary, faces[name])
                if candidates:
                    reduction, vert, T, rotated, reduced = candidates[0]
                    score = (reduction, -len(reduced), name)
                    if best is None or score > best[0]:
                        best = (score, name, reduction, vert, T, rotated, reduced)
            if best is None:
                break

            _, name, reduction, vert, T, rotated, reduced = best
            steps.append({
                "attach_face": name,
                "attachment_vertex": vert,
                "transporter_length": len(T),
                "reduction_count": reduction,
                "boundary_after_reduction_length": len(reduced),
            })
            order.append(name)
            remaining.remove(name)
            boundary = reduced

        if not remaining and reduce_word(boundary) == []:
            return {
                "shelling_found": True,
                "shelling_order": order,
                "number_faces": len(faces),
                "steps": steps,
                "final_reduced_word": [],
            }

    return {
        "shelling_found": False,
        "shelling_order": [],
        "number_faces": len(faces),
        "steps": [],
        "final_reduced_word": None,
    }


def internal_face_pairing_certificate(nx: int, ny: int, nz: int) -> Dict[str, Any]:
    grouped = defaultdict(list)
    for i in range(nx):
        for j in range(ny):
            for k in range(nz):
                for name, word in unit_cube_faces_at(i, j, k).items():
                    grouped[face_geom_key(word)].append((f"cube({i},{j},{k})/{name}", word))

    internal = []
    boundary = []
    failures = []

    for key, entries in grouped.items():
        if len(entries) == 1:
            boundary.append(entries[0][0])
        elif len(entries) == 2:
            (name1, word1), (name2, word2) = entries
            ok = cyclic_inverse_equal(word1, word2)
            internal.append({"faces": [name1, name2], "opposite_orientation_ok": ok})
            if not ok:
                failures.append({"faces": [name1, name2], "reason": "not cyclic inverse"})
        else:
            failures.append({"faces": [name for name, _ in entries], "reason": "face multiplicity not 1 or 2"})

    expected_boundary = 2 * (nx * ny + nx * nz + ny * nz)
    expected_internal = (
        (nx - 1) * ny * nz
        + nx * (ny - 1) * nz
        + nx * ny * (nz - 1)
    )

    return {
        "internal_pairing_ok": not failures,
        "number_boundary_faces": len(boundary),
        "expected_boundary_faces": expected_boundary,
        "number_internal_pairs": len(internal),
        "expected_internal_pairs": expected_internal,
        "failures": failures,
    }


def certify_template(nx: int, ny: int, nz: int) -> Dict[str, Any]:
    faces = cuboid_boundary_faces(nx, ny, nz)
    face_loop_checks = {name: is_closed_continuous(word) for name, word in faces.items()}
    edge_balance = edge_balance_certificate(faces)
    shelling = greedy_boundary_shelling(faces)
    internal = internal_face_pairing_certificate(nx, ny, nz)

    return {
        "template": f"cuboid_{nx}x{ny}x{nz}",
        "dimensions": [nx, ny, nz],
        "boundary_face_count": len(faces),
        "face_loop_checks_ok": all(face_loop_checks.values()),
        "edge_balance": edge_balance,
        "boundary_shelling": {
            "shelling_found": shelling["shelling_found"],
            "shelling_order": shelling["shelling_order"],
            "number_faces": shelling["number_faces"],
            "final_reduced_word": shelling["final_reduced_word"],
        },
        "internal_face_pairing": internal,
        "overall_pass": (
            all(face_loop_checks.values())
            and edge_balance["edge_balance_ok"]
            and shelling["shelling_found"]
            and shelling["final_reduced_word"] == []
            and internal["internal_pairing_ok"]
            and internal["number_boundary_faces"] == internal["expected_boundary_faces"]
            and internal["number_internal_pairs"] == internal["expected_internal_pairs"]
        ),
        "notes": [
            "Boundary-shelling certificate gives a direct nonabelian word proof for the cuboid boundary.",
            "Internal face pairing verifies opposite orientations in the unit-cube tiling.",
            "Arbitrary non-cuboidal cell topologies and arbitrary connector/stem catalogues are not covered.",
        ],
    }


def main() -> None:
    templates = [(1,1,1), (2,1,1), (2,2,1), (2,2,2), (3,3,3)]
    certs = [certify_template(*dims) for dims in templates]

    catalogue = {
        "certificate_name": "cuboidal_bianchi_template_catalogue",
        "version": "v0.1",
        "scope": (
            "Canonical axis-aligned cuboidal 3-cell templates embedded in a hypercubic lattice, "
            "up to coordinate relabelling and orientation reversal."
        ),
        "templates": certs,
        "overall_pass": all(c["overall_pass"] for c in certs),
        "limitations": [
            "This catalogue certifies the listed canonical cuboids only.",
            "A parametric proof is still needed for every cuboid size if the manuscript does not fix the block factor.",
            "Reflection-stem realizability is not certified here.",
            "Full retained/residual connector templates must be matched to this catalogue before submission.",
        ],
    }

    out = Path("ym_bianchi_cuboid_template_catalogue_certificate_v0_1.json")
    out.write_text(json.dumps(catalogue, indent=2), encoding="utf-8")

    print(f"Wrote {out}")
    print(f"overall_pass = {catalogue['overall_pass']}")
    for c in certs:
        print(f"{c['template']}: pass={c['overall_pass']}, faces={c['boundary_face_count']}")


if __name__ == "__main__":
    main()
