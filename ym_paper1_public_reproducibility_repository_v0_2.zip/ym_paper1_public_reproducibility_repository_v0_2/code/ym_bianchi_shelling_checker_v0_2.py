#!/usr/bin/env python3
"""
ym_bianchi_shelling_checker_v0_2.py

Elementary symbolic edge-word checker for the nonabelian Bianchi word
on one oriented unit cube.

This checker verifies a purely combinatorial word identity:
the ordered product of transported oriented face-boundary words of the
cube reduces to the empty word. It is not a full proof for every
retained/coarse template in the manuscript; it is the elementary cube
certificate engine to be extended template-by-template.

Conventions:
- vertices are bit strings "000", ..., "111";
- an oriented edge is a pair (u,v);
- the inverse edge is (v,u);
- word reduction cancels adjacent inverse edge pairs;
- face orientations are induced by the oriented cube [x,y,z].
"""

from __future__ import annotations
from itertools import permutations
from collections import Counter
import json
from pathlib import Path
from typing import Dict, List, Tuple, Optional, Any

Vertex = str
Edge = Tuple[Vertex, Vertex]
Word = List[Edge]


def inv_edge(e: Edge) -> Edge:
    return (e[1], e[0])


def inv_word(w: Word) -> Word:
    return [inv_edge(e) for e in reversed(w)]


def reduce_word(word: Word) -> Word:
    out: Word = []
    for e in word:
        if out and out[-1] == inv_edge(e):
            out.pop()
        else:
            out.append(e)
    return out


def vertices_to_edges(vs: List[Vertex]) -> Word:
    return [(vs[i], vs[(i + 1) % len(vs)]) for i in range(len(vs))]


def is_closed_continuous(word: Word) -> bool:
    if not word:
        return True
    cur = word[0][0]
    for e in word:
        if e[0] != cur:
            return False
        cur = e[1]
    return cur == word[0][0]


def rotate_cycle_to_vertex(edges: Word, start: Vertex) -> Optional[Word]:
    for i, e in enumerate(edges):
        if e[0] == start:
            return edges[i:] + edges[:i]
    return None


def boundary_vertices(boundary: Word) -> List[Vertex]:
    if not boundary:
        return ["000"]
    verts = [boundary[0][0]]
    cur = boundary[0][0]
    for e in boundary:
        if e[0] != cur:
            raise ValueError(f"Boundary is not continuous at {e}; expected source {cur}")
        cur = e[1]
        verts.append(cur)
    if verts[-1] != verts[0]:
        raise ValueError("Boundary is not closed")
    return verts[:-1]


def prefix_path_to_vertex(boundary: Word, vertex: Vertex) -> Optional[Word]:
    if not boundary:
        return [] if vertex == "000" else None
    path: Word = []
    cur = boundary[0][0]
    if cur == vertex:
        return []
    for e in boundary:
        path.append(e)
        cur = e[1]
        if cur == vertex:
            return path
    return None


# Oriented boundary faces of the oriented cube [x,y,z].
# These signs correspond to:
# ∂[xyz] = [yz]_{x=1} - [yz]_{x=0}
#          - [xz]_{y=1} + [xz]_{y=0}
#          + [xy]_{z=1} - [xy]_{z=0}
FACES: Dict[str, Word] = {
    "x1": vertices_to_edges(["100", "110", "111", "101"]),
    "x0": vertices_to_edges(["000", "001", "011", "010"]),
    "y1": vertices_to_edges(["010", "011", "111", "110"]),
    "y0": vertices_to_edges(["000", "100", "101", "001"]),
    "z1": vertices_to_edges(["001", "101", "111", "011"]),
    "z0": vertices_to_edges(["000", "010", "110", "100"]),
}


def edge_balance_certificate(faces: Dict[str, Word]) -> Dict[str, Any]:
    counts: Counter[Edge] = Counter()
    for word in faces.values():
        for e in word:
            counts[e] += 1

    failures = []
    checked = []
    for e in sorted(counts):
        inv = inv_edge(e)
        if str(e) <= str(inv):
            checked.append({
                "edge": list(e),
                "count_edge": counts[e],
                "inverse": list(inv),
                "count_inverse": counts[inv],
            })
        if counts[e] != counts[inv]:
            failures.append({
                "edge": list(e),
                "count_edge": counts[e],
                "inverse": list(inv),
                "count_inverse": counts[inv],
            })

    return {
        "edge_balance_ok": not failures,
        "failures": failures,
        "checked_pairs": checked,
    }


def attachment_candidates(boundary: Word, face: Word):
    candidates = []
    for v in boundary_vertices(boundary):
        T = prefix_path_to_vertex(boundary, v)
        if T is None:
            continue
        rotated = rotate_cycle_to_vertex(face, v)
        if rotated is None:
            continue
        trial = boundary + T + rotated + inv_word(T)
        reduced = reduce_word(trial)
        if is_closed_continuous(reduced) and len(reduced) < len(boundary) + len(rotated) + 2 * len(T):
            candidates.append((v, T, rotated, reduced))
    return candidates


def find_shelling_certificate(faces: Dict[str, Word]):
    # Start from a face that can be based at 000.
    for start_name, start_face in faces.items():
        start_word = rotate_cycle_to_vertex(start_face, "000")
        if start_word is None:
            continue

        stack = [([start_name], start_word, set(faces) - {start_name}, [])]

        while stack:
            order, boundary, remaining, steps = stack.pop()

            if not remaining:
                if reduce_word(boundary) == []:
                    return {
                        "shelling_found": True,
                        "start_face": order[0],
                        "shelling_order": order,
                        "steps": steps,
                        "final_reduced_word": [],
                    }
                continue

            for name in sorted(remaining):
                for vertex, T, rotated, reduced in attachment_candidates(boundary, faces[name]):
                    step = {
                        "attach_face": name,
                        "attachment_vertex": vertex,
                        "transporter": [list(e) for e in T],
                        "rotated_face_word": [list(e) for e in rotated],
                        "boundary_after_reduction": [list(e) for e in reduced],
                    }
                    stack.append((
                        order + [name],
                        reduced,
                        remaining - {name},
                        steps + [step],
                    ))

    return {
        "shelling_found": False,
        "shelling_order": [],
        "steps": [],
        "final_reduced_word": None,
    }


def main(output_path: str = "ym_bianchi_elementary_cube_certificate_v0_2.json") -> None:
    face_loop_checks = {
        name: is_closed_continuous(word)
        for name, word in FACES.items()
    }

    edge_balance = edge_balance_certificate(FACES)
    shelling = find_shelling_certificate(FACES)

    cert = {
        "certificate_name": "elementary_oriented_cube_nonabelian_bianchi_word_certificate",
        "version": "v0.2",
        "scope": (
            "One oriented unit cube. Verifies the elementary cube boundary "
            "word identity by symbolic edge-word reduction."
        ),
        "vertices": sorted({v for word in FACES.values() for e in word for v in e}),
        "faces": {
            name: [list(e) for e in word]
            for name, word in FACES.items()
        },
        "face_loop_checks": face_loop_checks,
        "edge_balance": edge_balance,
        "shelling_certificate": shelling,
        "overall_pass": (
            all(face_loop_checks.values())
            and edge_balance["edge_balance_ok"]
            and shelling["shelling_found"]
            and shelling["final_reduced_word"] == []
        ),
        "limitations": [
            "This verifies the elementary cube word identity only.",
            "It does not yet certify every coarse-cell template or retained/residual connector template.",
            "Template-specific certificates must be generated after the manuscript's exact cell/stem/connector catalogue is fixed.",
        ],
    }

    path = Path(output_path)
    path.write_text(json.dumps(cert, indent=2), encoding="utf-8")

    print(f"Wrote {path}")
    print(f"overall_pass = {cert['overall_pass']}")
    print(f"shelling_order = {shelling.get('shelling_order')}")


if __name__ == "__main__":
    main()
