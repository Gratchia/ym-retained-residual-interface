#!/usr/bin/env python3
"""
ym_reflection_stem_checker_v0_1.py

Symbolic checker for the reflection-admissible retained-stem condition.

Scope:
- Checks a declared finite retained word tuple W_i.
- Checks a declared reflection action on oriented edge-symbols.
- Checks a declared common conjugating word C, permutation pi, and inversion flags eps_i.
- Verifies:
      red(Theta W_i) = red(C W_{pi(i)}^{eps_i} C^{-1})
  for every retained generator i.

This is a checker for a supplied template. It does not discover the correct
stem tree or prove every geometric template automatically.
"""

from __future__ import annotations
from pathlib import Path
from typing import List, Dict, Any, Tuple
import json
import sys

Token = str
Word = List[Token]


def inv_token(tok: Token) -> Token:
    if tok.startswith("-"):
        return tok[1:]
    return "-" + tok


def inv_word(word: Word) -> Word:
    return [inv_token(t) for t in reversed(word)]


def reduce_word(word: Word) -> Word:
    out: Word = []
    for tok in word:
        if out and out[-1] == inv_token(tok):
            out.pop()
        else:
            out.append(tok)
    return out


def apply_reflection(word: Word, reflection: Dict[str, Word]) -> Word:
    out: Word = []
    for tok in word:
        if tok in reflection:
            out.extend(reflection[tok])
        elif tok.startswith("-") and tok[1:] in reflection:
            out.extend(inv_word(reflection[tok[1:]]))
        else:
            raise KeyError(f"No reflection image declared for token {tok}")
    return reduce_word(out)


def check_spec(spec: Dict[str, Any]) -> Dict[str, Any]:
    retained: List[Word] = spec["retained_words"]
    reflection: Dict[str, Word] = spec["reflection"]
    C: Word = spec["common_conjugator"]
    pi: List[int] = spec["permutation"]
    eps: List[int] = spec["inversions"]

    failures = []
    checks = []

    if len(pi) != len(retained) or len(eps) != len(retained):
        raise ValueError("permutation and inversions must match retained_words length")

    C_red = reduce_word(C)

    for i, W in enumerate(retained):
        lhs = reduce_word(apply_reflection(W, reflection))
        target = retained[pi[i]]
        if eps[i] == -1:
            target = inv_word(target)
        elif eps[i] != 1:
            raise ValueError("inversions entries must be +1 or -1")

        rhs = reduce_word(C_red + target + inv_word(C_red))
        ok = lhs == rhs
        record = {
            "index": i,
            "lhs_reflected_reduced": lhs,
            "target_index": pi[i],
            "epsilon": eps[i],
            "rhs_common_conjugated_reduced": rhs,
            "ok": ok,
        }
        checks.append(record)
        if not ok:
            failures.append(record)

    return {
        "template_name": spec.get("template_name", "unnamed_template"),
        "condition": "Theta W_i = C W_{pi(i)}^{eps_i} C^{-1} for all i, after reduction",
        "number_retained_words": len(retained),
        "common_conjugator_reduced": C_red,
        "all_pass": not failures,
        "checks": checks,
        "failures": failures,
        "limitations": [
            "This checks only the submitted word template.",
            "It does not prove existence of a good stem tree.",
            "It does not certify positive-time support or Bianchi word cancellation.",
            "It does not establish analytic estimates."
        ],
    }


def main() -> None:
    if len(sys.argv) < 2:
        # write and check a toy demonstration only
        spec = {
            "template_name": "toy_common_conjugation_demo_not_project_certificate",
            "retained_words": [
                ["a", "b", "-a", "-b"],
                ["a", "c", "-a", "-c"],
            ],
            "reflection": {
                "a": ["r", "a", "-r"],
                "b": ["r", "c", "-r"],
                "c": ["r", "b", "-r"],
                "r": ["r"],
            },
            "common_conjugator": ["r"],
            "permutation": [1, 0],
            "inversions": [1, 1],
        }
        out = check_spec(spec)
        Path("ym_reflection_stem_toy_certificate_v0_1.json").write_text(json.dumps(out, indent=2), encoding="utf-8")
        print("No input provided. Wrote toy demonstration certificate:")
        print("ym_reflection_stem_toy_certificate_v0_1.json")
        print(f"all_pass = {out['all_pass']}")
        return

    in_path = Path(sys.argv[1])
    spec = json.loads(in_path.read_text(encoding="utf-8"))
    out = check_spec(spec)
    out_path = in_path.with_suffix(".certificate.json")
    out_path.write_text(json.dumps(out, indent=2), encoding="utf-8")
    print(f"Wrote {out_path}")
    print(f"all_pass = {out['all_pass']}")


if __name__ == "__main__":
    main()
