# Full-Text Novelty-Overlap Audit: Batrouni 1982 and Borisenko--Voloshin--Faber

**Paper under audit:** `YM-P1` — *A Bianchi-Compatible Retained/Residual Interface for Finite Lattice Yang--Mills Theory*  
**Audit revision:** `P8-FT-2026-07-17-001`  
**Source texts uploaded by author:**  
1. `batrouni-1982-plaquette-formulation-bianchi-identity.pdf`  
2. `borisenko-voloshin-faber-2009-field-strength-bianchi.pdf`

---

## Executive verdict

\[
\boxed{\text{The full-text check strengthens the prior-art warning but does not eliminate YM-P1's narrow qualified contribution.}}
\]

The audit confirms that YM-P1 must not claim novelty for:

- plaquette formulation of lattice gauge theories;
- lattice Bianchi identities;
- nonabelian Bianchi constraints;
- gauge-invariant plaquettes;
- connector structures in nonabelian Bianchi identities;
- simplification or abelianization of nonabelian Bianchi identities;
- plaquette-representation perturbation theory.

The audit does **not** find that Batrouni or Borisenko--Voloshin--Faber already formulate the exact same package as YM-P1:

\[
\text{retained/residual coordinate interface}
+
\text{covariant/quotient separation}
+
\text{Bianchi-relevant residual projection}
+
\text{positive-support pullback theorem}
+
\text{reflection-admissible common-conjugation stem diagnostic}
+
\text{exact/exposed/future diagnostic ledger}.
\]

Therefore the safe contribution remains:

\[
\boxed{
\text{finite-regulator retained/residual structural interface under certified-template and admissibility assumptions.}
}
\]

---

## 1. Batrouni 1982 overlap

### 1.1 Direct overlap found

Batrouni explicitly develops a lattice plaquette-variable formulation for Abelian and nonabelian lattice gauge theories, with the lattice Bianchi identity as the central structural object. The abstract states that new results include a plaquette formulation of all lattice gauge theories, a strong-coupling interpretation as restoration of the Bianchi identity, a geometrical interpretation of the lattice Bianchi identity, and discussion of abelianization and gauge-invariant variables.

This directly overlaps with any possible claim that YM-P1 introduces plaquette/Bianchi variables or the basic Bianchi constraint.

### 1.2 Gauge-invariant plaquettes and tails

Batrouni expresses link variables in a path gauge and interprets links as Wilson loops filled with plaquettes. He also states that remaining plaquettes may be thought of as gauge-invariant plaquettes with tails along gauge lines.

This overlaps with any broad claim that stemmed or tailed plaquettes are new.

### 1.3 Abelianization and nonlocal obstruction

Batrouni studies abelianization of the nonabelian lattice Bianchi identity, including expressing a cube identity as a product of six gauge-invariant plaquettes. He also records that a total/global abelianization was not achieved and that cavities or nonlocalities appear.

This matters because YM-P1's reflection/stem/connector restrictions should be framed as a finite-template structural discipline, not as a new discovery that Bianchi identities can be transported or abelianized.

### 1.4 What Batrouni does not appear to contain

No direct occurrence was found of the YM-P1 package:

- retained/residual split;
- \(Y_k^{\rm res,loc}\) as a typed residual map;
- Bianchi projection \(Y_k^B=\pi_B\circ Y_k^{\rm res,loc}\);
- quotient interface \(\Phi_k^{\rm quot}=(X_k,[Y_k])\);
- covariant interface \(\Phi_k^{\rm cov}\) separated from quotient observables;
- positive-time support pullback theorem;
- reflection-admissible common-conjugation stem diagnostic \(N_k^{\rm stem/RP}\);
- exact/exposed/future diagnostic ledger.

---

## 2. Borisenko--Voloshin--Faber overlap

### 2.1 Direct overlap found

Borisenko--Voloshin--Faber explicitly start from the Batrouni formulation and modify it so each nonabelian Bianchi identity contains two connectors instead of four. They work in the plaquette representation, with plaquette matrices as fundamental degrees of freedom constrained by Bianchi identities.

This directly overlaps with any broad YM-P1 claim about connector-reduced Bianchi constraints.

### 2.2 Maximal axial gauge and Jacobian constraints

They recall the Batrouni construction in maximal axial gauge, with plaquette matrices \(V_p\), a product over cubes, a Jacobian \(J(V_c)\), and an \(SU(N)\) delta-function implementing the lattice Bianchi identity. They emphasize that the nonabelian constraints are highly nonlocal.

This means YM-P1 should not present nonlocal connector bookkeeping as surprising or new. It should cite this prior art and state that its own role is to organize exact-image support constraints inside its retained/residual interface.

### 2.3 Connector structure

They define vertices \(A\) and \(B\), a connector \(C\), and four types of connector sublattices, then reduce connector count. This overlaps with any claim that YM-P1 introduces connector paths for Bianchi products.

### 2.4 What Borisenko--Voloshin--Faber does not appear to contain

No direct occurrence was found of the YM-P1 package:

- retained/residual coordinate interface;
- gauge-invariant quotient pushforward \(\mu_k^{XY}\);
- regular conditional kernel \(K_k(dy\mid x)\) used as a structural disintegration rather than a perturbative plaquette representation;
- positive-time support algebra \(\mathcal A_{+,k}^{X,Y}\);
- reflection-admissible stem/common-conjugation condition;
- diagnostic ledger separating exact/exposed/future statements;
- certified word-checker catalogue for exact-image cuboidal templates.

---

## 3. Impact on YM-P1 claims

### 3.1 Claims now explicitly forbidden

YM-P1 must not say or imply:

\[
\text{we introduce the lattice Bianchi identity}
\]

\[
\text{we introduce plaquette formulation}
\]

\[
\text{we introduce connector Bianchi constraints}
\]

\[
\text{we introduce gauge-invariant plaquette tails}
\]

\[
\text{we are the first Bianchi-compatible retained/blocking construction}
\]

\[
\text{we simplify nonabelian Bianchi identities generally}
\]

\[
\text{we construct a plaquette representation of Yang--Mills}
\]

\[
\text{we construct a full blocking/RG map}
\]

### 3.2 Claims still allowed

YM-P1 may claim:

\[
\boxed{
\text{a finite-regulator retained/residual interface that records exact structural compatibility conditions.}
}
\]

More specifically, it may claim:

1. A separation between covariant connector/Bianchi bookkeeping and gauge-invariant quotient observables/measures.
2. A typed residual-coordinate layer \(Y_k^{\rm res,loc}\) and Bianchi projection \(Y_k^B\).
3. Exact-image Bianchi compatibility for certified cuboidal templates, not a new Bianchi identity.
4. A positive-support pullback theorem for quotient coordinate observables.
5. A reflection-admissible common-conjugation condition for retained stemmed-loop tuples.
6. A diagnostic ledger separating exact structural conditions, exposed chart/frame/stratum records, and future analytic templates.

---

## 4. Required manuscript patch

The prior-work paragraph should be strengthened:

> Batrouni's plaquette formulation already places lattice Bianchi identities at the center of the plaquette-variable description of Abelian and nonabelian lattice gauge theory, including gauge-invariant plaquettes and abelianization questions. Borisenko--Voloshin--Faber further refine this direction by modifying Batrouni's nonabelian Bianchi constraints so that each identity contains two connectors instead of four. The present paper does not claim novelty for plaquette variables, Bianchi identities, gauge-invariant plaquettes, or connector structures. Its contribution is instead the retained/residual interface and the claim-control discipline described below.

---

## 5. Readiness consequence

The major Bianchi/connector novelty risk has been controlled by full-text review.

Recommended scientific state:

\[
\boxed{SR4Q\text{ recommended, pending human-author adoption.}}
\]

Qualification:

\[
\boxed{
\text{finite-regulator structural interface under certified cuboidal-template and conditional reflection-admissibility assumptions.}
}
\]

Integrity state remains:

\[
\boxed{MI3}
\]

because manuscript integrity, page-by-page human review, rights/conflicts/funding, AI-use disclosure, and final submission-channel formatting remain open.

---

## 6. PAP + RCG result

**PAP:** Full-text novelty-overlap audit used the uploaded Batrouni and Borisenko--Voloshin--Faber papers. No manuscript text was copied. The audit strengthens citation discipline and narrows contribution language.

**RCG:** Aligned. Claim level remains finite-regulator structural. No continuum construction, OS reconstruction, transfer decay, confinement, or mass gap is claimed.

---

## 7. Final audit verdict

\[
\boxed{
\text{Full-text audit clears YM-P1 only as a qualified finite-regulator structural interface paper.}
}
\]

It does **not** clear the paper for broad novelty or any mass-gap-level claim.
