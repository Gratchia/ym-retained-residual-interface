# YM-P1 Internal Similarity and Provenance Report v1.1

**Paper:** `YM-P1`  
**Manuscript checked:** `ym_paper1_integrated_manuscript_v0_9.pdf`  
**Date:** 2026-07-17  
**Status:** Internal/local report only; not an institutional iThenticate/Turnitin report.

---

## Scope

This screen compares the current manuscript against the two uploaded full-text prior-art sources most directly relevant to the plaquette/Bianchi part of the paper:

1. Batrouni 1982.
2. Borisenko--Voloshin--Faber.

The test used local text extraction and exact n-gram overlap checks. It is useful as a provenance control, but it does not replace a journal or institutional similarity report.

---

## Summary result

\[
\boxed{\text{No high-risk long verbatim overlap was detected in this local screen.}}
\]

Conceptual overlap remains high in plaquette/Bianchi/connector topics, but the manuscript now explicitly cites the sources and disclaims novelty in those areas.

---

## Exact-overlap results

```json
{
  "Batrouni 1982": {
    "12-gram_count": 0,
    "12-gram_examples": [],
    "10-gram_count": 1,
    "10-gram_examples": [
      [
        "plaquette formulation and the bianchi identity for lattice gauge theories",
        1
      ]
    ],
    "8-gram_count": 3,
    "8-gram_examples": [
      [
        "and the bianchi identity for lattice gauge theories",
        1
      ],
      [
        "formulation and the bianchi identity for lattice gauge",
        1
      ],
      [
        "plaquette formulation and the bianchi identity for lattice",
        1
      ]
    ],
    "5gram_jaccard": 0.0007481296758104738
  },
  "Borisenko-Voloshin-Faber": {
    "12-gram_count": 0,
    "12-gram_examples": [],
    "10-gram_count": 0,
    "10-gram_examples": [],
    "8-gram_count": 0,
    "8-gram_examples": [],
    "5gram_jaccard": 8.655760408551892e-05
  }
}
```

---

## Interpretation

- Any overlap with paper titles, reference entries, author names, or standard technical phrases is not considered a plagiarism concern by itself.
- The main risk is not verbatim copying; it is conceptual overclaim. That risk is controlled by the strengthened prior-work section and the mandatory SR4Q qualification.
- For final MI4, the human author should still obtain or approve a formal similarity/provenance record if required by the institution or target journal.

---

## MI4 impact

\[
\boxed{\text{Internal similarity screen: pass. Formal institutional/journal similarity report: still recommended.}}
\]
