# SciPost Physics Core Submission-Preparation Checklist for YM-P1 v1.0

Date: 2026-07-17

## Target journal

**Selected target journal:** SciPost Physics Core  
**Likely specialties:** High-Energy Physics - Theory; Mathematical Physics  
**Manuscript candidate:** `ym_paper1_scipost_core_candidate_v1_2.pdf`

## Current channel state

\[
\boxed{\text{Target journal selected; channel preparation underway.}}
\]

Recommended tuple after this step:

\[
\boxed{(SR4Q,MI4,CH0/CH2/CH1,RA0)}
\]

where:

- `CH0` preprint server not selected yet;
- `CH2` target-journal preparation underway for SciPost Physics Core;
- `CH1` public repository desired/private package prepared, but public repository not yet created.

## SciPost Physics Core criteria mapping

| SciPost Core requirement | Current YM-P1 status | Action |
|---|---|---|
| Important problem and appropriate methods | Addresses finite-regulator structural issues in lattice Yang--Mills interface design. | Keep narrow claim language. |
| Above-the-norm originality and new result | Narrow originality: retained/residual interface with certified-template Bianchi compatibility and diagnostic discipline. | Emphasize qualified contribution; do not overclaim. |
| Clear, intelligible writing | Manuscript is short and structured. | Final copyedit still recommended. |
| Reproducible arguments/derivations | Theorems are finite-regulator; Bianchi checkers/certificates exist. | Add public repository URL before submission. |
| Representative citations | Core Bianchi/plaquette prior art cited and discussed. | Consider one last human bibliography scan. |
| Clear conclusion with limitations | v1.2 now has `Conclusion and outlook`. | Done. |
| Detailed abstract/introduction | Abstract and introduction are present and claim-controlled. | Done. |
| Reproducibility resources | Private package exists. | Public repository or archival DOI still needed. |

## SciPost authoring-format checks

| Requirement | Status |
|---|---|
| 10pt if not using SciPost template | `PASS`: v1.2 uses 10pt article class. |
| Hyperlinks for equations/references | `PASS initial`: hyperref used. |
| DOI links in references | `PASS initial`: DOI links present for journal articles. |
| Title within about two lines | `PASS initial`. |
| Authors with affiliation | `PASS initial`: author/affiliation present; corresponding author marked. |
| Abstract under about 200 words | `PASS initial`. |
| Funding information | `PASS`: no external funding declared. |
| Competing interests | `PASS`: no competing interests declared. |
| Supplementary/reproducibility material | `PENDING`: public repository URL/DOI required before submission. |

## Remaining blockers before submission

1. Provide corresponding-author email for the SciPost submission form and optionally manuscript footnote.
2. Decide preprint route: arXiv first, or direct SciPost submission.
3. Create public repository/archive for reproducibility package and insert URL/DOI in manuscript.
4. Choose license for code/checker scripts.
5. Perform final bibliography/source check.
6. Final human signoff authorizing one exact action: arXiv upload, SciPost direct submission, or repository publication.

## Current release authorization

\[
\boxed{RA0}
\]

No public action is authorized by this checklist.
